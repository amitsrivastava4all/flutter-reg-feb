import './screens/first.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main(){
  // Material App - I am a Top Level Widget, And I am Using Material Design
  runApp(MaterialApp(
    // navigation , Themes , Home
    debugShowCheckedModeBanner: false,
    //theme: ThemeData.dark(),
    //theme: ThemeData.light(),
    theme: ThemeData(
      
      appBarTheme: AppBarTheme(backgroundColor: Colors.orangeAccent)),
    title: 'First App',
    //home: SafeArea(child: Text('Hello Flutter')),
    home:First()
  ));
}