import 'package:flutter/material.dart';

class First extends StatelessWidget{
  @override
  Widget build(BuildContext ctx){
    // UI Design Here
    return Scaffold(
      persistentFooterButtons: [
        ElevatedButton(onPressed: (){},child: Icon(Icons.email),),ElevatedButton(onPressed: (){},child: Icon(Icons.alarm),)
      ],
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.deepOrangeAccent,
        onPressed: (){},
        child: Text('+',style: TextStyle(fontSize: 30),),
      ),
      drawer: Drawer(
        child: UserAccountsDrawerHeader(accountName: Text('Amit'), accountEmail: Text('amit@yahoo.com')),
      ),
     // body: Center(child: Text('Hello Flutter', style: TextStyle(fontSize: 40),),),
      //body: Image.network('https://m.media-amazon.com/images/M/MV5BMTk3NDE5MzM3NF5BMl5BanBnXkFtZTgwNDQ3Nzk3ODE@._V1_.jpg'),
      body: Image.asset('images/dp.jpeg'),
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(100),
        child: AppBar(
          //automaticallyImplyLeading: false,
          centerTitle: true,
          elevation: 10,
          shadowColor: Colors.green,
          backgroundColor: Colors.pinkAccent,
          //leading: Icon(Icons.menu),
          actions: [Icon(Icons.phone, color: Colors.black,), SizedBox(width:10), Icon(Icons.message, color: Colors.black,), SizedBox(width: 15,)],
          title: Text('First App'),),
      ),
    );
  }
}