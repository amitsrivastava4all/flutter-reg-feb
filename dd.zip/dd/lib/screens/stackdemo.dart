
import 'package:flutter/material.dart';

class StackDemo extends StatelessWidget {
  const StackDemo({ Key? key }) : super(key: key);

  _getContainer(Color color,{double width= 100, double height=100}){
    return Container(color: color,width:width ,height:  height,);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          color: Colors.white,
          width: 400,
          height: 400,
          //width: double.infinity,
          //height: double.infinity,
          child: Stack(
           // fit: StackFit.passthrough,
            children: [
              Positioned(child:  _getContainer(Colors.orange, width: 400, height: 400), top:30, left: 50,)
             ,
             Positioned(child:  _getContainer(Colors.green, width: 300, height: 300), bottom: 50, right: 10,)
             ,
              _getContainer(Colors.blue)
            //
            //Container(color: Colors.blue,),
            // Card(
            //   elevation: 10,
            //   shadowColor: Colors.blue,
            //   margin: EdgeInsets.all(20),
            //   child: Image.network('https://www.redwolf.in/image/catalog/designer-Images/themes/iron-man-artist-image.png'
            
            // ),
            // ),
            // // Image.network('https://www.redwolf.in/image/catalog/designer-Images/themes/iron-man-artist-image.png'
            // // ,fit: BoxFit.cover
            // // ),
            
            // Positioned(
            //   bottom: 10,
            //   right :10,
            //   child: Text('Iron Man', style: TextStyle(fontSize: 40),))
            //_getContainer(Colors.green, width: 400, height: 400),
             //_getContainer(Colors.red, width: 300, height: 300),
             // _getContainer(Colors.blue),
          ],),
        ),
      ),
      
    );
  }
}