
import 'package:flutter/material.dart';
import 'package:music_app/utils/api_client.dart';
import 'package:music_app/widgets/song.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as converter;
class MusicList extends StatefulWidget {
  const MusicList({ Key? key }) : super(key: key);

  @override
  _MusicListState createState() => _MusicListState();
}

class _MusicListState extends State<MusicList> {
  ApiClient _apiClient = ApiClient();
  getAllSongs(){
     Future<http.Response> future =   _apiClient.getSongs();
     future.then((response) {
        String json = response.body;
        print("JSON $json");
        var map = converter.jsonDecode(json);
        print("******************************");
        print("MAp is $map");
        final list = map['results'];
        print("#######################");
        print("List is $list");
        _prepareSongs(list);
        setState(() {
          
        });
     }).catchError((err)=>print("Error $err"));
  }
  List<Widget> list = [];
  List<Widget> _prepareSongs(List<dynamic> list){
    this.list =  list.
    map((song)=>Song(imageURL:song['artworkUrl100'] , audioURL: song['previewUrl'], artistName: song['artistName'], trackName: song['trackName'])).toList();
    return this.list;
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getAllSongs();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body:SafeArea(child:SingleChildScrollView(child:Column(children: list.length>0?list:[Text('Loading...')],)
    )));
  }
}