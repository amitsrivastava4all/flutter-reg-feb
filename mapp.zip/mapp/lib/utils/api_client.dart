import 'package:http/http.dart' as http;

class ApiClient{
  // Network Call
  String URL = "https://itunes.apple.com/search?term=daler+mehndi";
  getSongs(){
      Uri url = Uri.parse(URL);  
      Future<http.Response> future = http.get(url);
      return future;
  }
}