import 'package:flutter/material.dart';
import 'package:music_app/screens/musiclist.dart';

void main(){
  runApp(MaterialApp(
    home: MusicList(),
  ));
}