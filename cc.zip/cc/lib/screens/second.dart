import 'dart:math';

import 'package:flutter/material.dart';

class Second extends StatelessWidget {
  const Second({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          transform: Matrix4.rotationZ(pi/5),
          decoration: BoxDecoration(
           
            boxShadow: [BoxShadow(color: Colors.deepOrange,blurRadius: 5), BoxShadow(color: Colors.pinkAccent,blurRadius: 7)],
            border: Border.all(color: Colors.black, width: 4),
            //shape:BoxShape.circle,
            //image: DecorationImage(image: AssetImage('images/t.png')),
           // gradient: LinearGradient(colors: [Colors.yellowAccent, Colors.tealAccent, Colors.orangeAccent],begin: Alignment.topLeft, end:Alignment.bottomRight)
            //gradient: RadialGradient(colors: [Colors.yellowAccent, Colors.tealAccent, Colors.orangeAccent],stops: [0.5,0.8,0.9])
            gradient: SweepGradient(colors: [Colors.yellowAccent, Colors.blue, Colors.orangeAccent],stops: [0.2,0.8,0.9])
          ),
          //width: double.infinity,
          //height: double.infinity,
          width: 500,
          height: 500,
          //color: Colors.amberAccent,
          //child: Text('Hello Flutter',style: TextStyle(fontSize: 30),
        ),
      ));
    
  }
}