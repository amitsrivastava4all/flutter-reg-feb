// INternal State (Data)
import 'package:flutter/material.dart';

class CounterApp extends StatefulWidget {
  const CounterApp({ Key? key }) : super(key: key);

  @override
  _CounterAppState createState() => _CounterAppState();
}

class _CounterAppState extends State<CounterApp> {
  late int counter ;
  _plus(){
    counter++;
    print("Plus Call $counter");
    setState(() {
      
    });
  }

  @override
  void didUpdateWidget(covariant CounterApp oldWidget) {
    // TODO: implement didUpdateWidget
    super.didUpdateWidget(oldWidget);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print("1. nInit State Call");
    counter = 0;
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    print("Call At the End");
  }

  @override
  void deactivate() {
    // TODO: implement deactivate
    super.deactivate();
    print("State Going to remove...");
  }

  

  String _value = "";
  TextEditingController tc = TextEditingController();

  @override
  Widget build(BuildContext context) {
    print("2. I am the Build function.....");
    return Scaffold(
      body: Center(child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(18.0),
            child: TextField(
              controller: tc,
      //         onChanged: (String val){
      //           _value=val;
      // //           setState(() {
        
      // // }
      //         //);
      //         },
              cursorColor: Colors.red,
              cursorWidth: 10,
              cursorHeight: 20,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(

                labelText: 'Type Name Here',
                hintText: 'Enter Name',
                prefixIcon: Icon(Icons.person),
                suffixIcon: Icon(Icons.arrow_right),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))
              ),
            ),
            
          ),
          ElevatedButton(
            onPressed: (){
              _value = tc.text;
              setState(() {
                
              });
            }, child: Text('Click Me'),
          ),
          Text('Name is $_value', style: TextStyle(fontSize: 30),),
          Text('Counter Value is $counter', 
        style: TextStyle(fontSize: 30),),
        ]),),
        floatingActionButton: FloatingActionButton(onPressed: (){
          _plus();
        },child: Text('+', style: TextStyle(fontSize: 35),),),
    );
  }
}