import '/screens/widgets/textbox.dart';
import 'package:flutter/material.dart';
import '/screens/widgets/range_slider.dart' as rs;
class Emi extends StatefulWidget {
  const Emi({ Key? key }) : super(key: key);

  @override
  _EmiState createState() => _EmiState();
}

class _EmiState extends State<Emi> {
   double? _value ;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _value = 1.0;
  }
  _sliderValueUpdate(double value){
      _value = value;
      tenure.text = _value!.toInt().toString();
      setState(() {
        
      });
  }
  TextEditingController pr = TextEditingController();
  TextEditingController roi = TextEditingController();
  TextEditingController tenure = TextEditingController();
  _compute(){
    int prValue = int.parse(pr.text);
    int tenureValue = int.parse(tenure.text); // Assume Month
    double monthlyPrEMI = prValue  / tenureValue;
    double roiValue = double.parse(roi.text);
    double monthlyROI = (prValue * (roiValue/100))/tenureValue;
    print("Pr $prValue ROI $roiValue Tenure $tenureValue");
    print("Monthly Pr $monthlyPrEMI Monthly ROI $monthlyROI EMI ${(monthlyPrEMI + monthlyROI)}");
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text('EMI Calc'),),
        body: Column(
          
          children: [
            TextBox('Home Loan Principle', Icons.keyboard,pr),
            TextBox('ROI', Icons.accessible,roi),
            TextBox('Tenure', Icons.account_balance_wallet,tenure),
            rs.RangeSlider(_value??1.0, _sliderValueUpdate),
            ElevatedButton(onPressed: (){
                _compute();
            }, child: Text('EMI Compute'))
        ],) ,
    );
  }
}