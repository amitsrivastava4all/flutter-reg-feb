import 'package:flutter/material.dart';

class Third extends StatelessWidget {
  const Third({ Key? key }) : super(key: key);

  _showContainer(Color color, [double width = 50, double height = 50]){
    //return Image.network()
    return Container(color: color, width: width, height: height);
  }
  _showText(String txt, {double fontSize = 18}){
    return Text(txt, style: TextStyle(fontSize: fontSize),);
  }
  _showImages(String url , {int flex = 1}){
    return Expanded(child: Image.network(url), flex: flex,);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: 
        Column(
          //Row(
          mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment:  CrossAxisAlignment.center,
            //crossAxisAlignment: CrossAxisAlignment.baseline,
            //textBaseline: TextBaseline.ideographic,
            //textDirection: TextDirection.rtl,
            children: [
            //  _showText("Hi"),
             // _showText("Hello ",fontSize: 40),
             // _showText("Ok")

               // _showContainer(Colors.redAccent),
                // _showContainer(Colors.green, 100,100), 
                // _showContainer(Colors.blue)
                _showImages('https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Deadpool%2C_Georgia_Viaduct%2C_Vancouver%2C_April_6_2015_-_3.jpg/800px-Deadpool%2C_Georgia_Viaduct%2C_Vancouver%2C_April_6_2015_-_3.jpg'),
                _showImages('https://media.fortniteapi.io/images/887cbde3ba5120dda6d504dd8e85a417/transparent.png', flex: 3),
                _showImages('https://m.media-amazon.com/images/M/MV5BYzE5MjY1ZDgtMTkyNC00MTMyLThhMjAtZGI5OTE1NzFlZGJjXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg', flex: 2)
            ],
        ),
      ),
    );
  }
}