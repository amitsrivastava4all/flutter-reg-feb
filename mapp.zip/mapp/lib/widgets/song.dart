import 'package:flutter/material.dart';

class Song extends StatelessWidget {
  late String imageURL;
  late String audioURL;
  late String artistName;
  late String trackName;
  Song({required String imageURL, required String audioURL, required String artistName, required String trackName}){
    this.imageURL = imageURL;
    this.audioURL = audioURL;
    this.artistName = artistName;
    this.trackName = trackName;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListTile(
        leading: Image.network(imageURL),
        title:Text(artistName),
        subtitle: Text(trackName),
        trailing: IconButton( onPressed: (){
          // Play 
        },icon: Icon(Icons.play_arrow),),
      ),
    );
  }
}